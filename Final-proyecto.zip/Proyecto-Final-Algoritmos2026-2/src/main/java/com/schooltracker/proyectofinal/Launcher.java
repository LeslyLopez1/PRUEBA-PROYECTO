package com.schooltracker.proyectofinal;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(Aplicacion.class, args);
    }
}
