# Análisis teórico de complejidad

Notación: **V** = número de vértices, **E** = número de aristas, **n** = número de elementos a ordenar
(en el ordenamiento, n = E, porque se ordena la lista de aristas), **d** = grado de un vértice.
Las complejidades son las del código de este proyecto (listas de adyacencia en `Grafo`).

## Resumen

| Operación | Mejor caso | Caso promedio | Peor caso | Espacio extra |
|---|---|---|---|---|
| Lectura del CSV + construcción del grafo (`Lector`, `Grafo`) | O(V³ + E·V) | O(V³ + E·V) | O(V³ + E·V) | O(V² + E) |
| BFS | O(V + E) | O(V + E) | O(V + E) | O(V) |
| DFS | O(V + E) | O(V + E) | O(V + E) | O(V) |
| Dijkstra (cola de prioridad) | O((V + E) log V) | O((V + E) log V) | O((V + E) log V) | O(V + E) |
| QuickSort (pivote = primer elemento) | O(n log n) | O(n log n) | O(n²) | O(log n) promedio, O(n) peor |
| Shell Sort (saltos n/2, n/4, ..., 1) | O(n log n) | alrededor de O(n^1.5) | O(n²) | O(1) |

## Lectura del CSV y construcción del grafo

- Leer el archivo recorre cada línea una vez: **O(L)** líneas, con L ≈ E. Cada línea se separa con `split`
  y los nombres se buscan en un `HashMap` (O(1) promedio).
- `Grafo.agregarVertice` redimensiona la matriz de adyacencia creando una matriz nueva de n×n y copiando la
  anterior: **O(V²) por vértice**, por lo que agregar los V vértices cuesta **O(V³)**.
- `Grafo.agregarArista` revisa si la conexión ya existe recorriendo la lista del origen (**O(d)**) y actualiza la
  matriz con `indexOf` sobre la lista de índices (**O(V)**), por lo que cada arista cuesta **O(V + d) = O(V)**.
- Total: **O(V³ + E·V)**. En grafos densos (E cercano a V²) el segundo término domina; en grafos ralos domina V³.
- Observación para el reporte: los grafos de 500 vértices tardan mucho más en importarse y construirse que en
  recorrerse con BFS o DFS, porque la matriz de adyacencia (requerida por el enunciado) se reconstruye en cada
  alta. Si la matriz se reservara una sola vez con el tamaño final, la construcción bajaría a O(V² + E).

## BFS y DFS

Ambos visitan cada vértice una vez (O(V)) y recorren la lista de adyacencia de cada vértice una vez, es decir,
cada arista una vez (O(E)). Consultas a `HashSet` y a `Queue`/`Stack`: O(1). Total **O(V + E)**.
Con matriz de adyacencia serían O(V²), pero aquí se usan listas.
El DFS usa una pila explícita en lugar de recursión, así que no se desborda con grafos grandes.

## Dijkstra

Se usa una `PriorityQueue` con "eliminación perezosa" (un vértice puede entrar varias veces a la cola y se
ignora si ya fue visitado). Cada arista puede provocar una inserción en la cola (O(log E) = O(log V)) y cada
vértice se extrae al menos una vez: **O((V + E) log V)**. Requiere pesos no negativos (el programa lo valida).

## QuickSort (versión vista en clase, pivote en el primer elemento)

- Mejor y promedio: la partición divide en mitades parecidas: T(n) = 2T(n/2) + O(n) = **O(n log n)**.
- Peor caso: lista ya ordenada (o inversa). Cada partición deja un lado vacío: T(n) = T(n−1) + O(n) = **O(n²)**
  y la recursión llega a profundidad n; con listas ya ordenadas de decenas de miles de elementos Java lanza
  `StackOverflowError` (el programa lo detecta y avisa).
- Las aristas salen de un archivo en orden aleatorio, por eso en la práctica se comporta como O(n log n).

## Shell Sort (versión vista en clase)

Insertion sort con saltos que empiezan en n/2 y se reducen a la mitad hasta llegar a 1.
- Peor caso con esta secuencia: **O(n²)**. En la práctica con datos aleatorios se acerca a **O(n^1.5)**.
- No usa recursión ni memoria extra: **O(1)**.
- Comparación esperada: Shell Sort es competitivo con listas pequeñas, pero QuickSort gana al crecer n.

## Cómo se relaciona con las mediciones (pantalla "Analisis")

- Al crecer V y E, **BFS y DFS** crecen de forma moderada (lineal en V + E).
- **Importación y construcción** crecen más rápido por el término V³ / E·V descrito arriba.
- **Dijkstra** queda entre BFS y los ordenamientos (el factor log V).
- **QuickSort** y **Shell Sort**: Shell se separa hacia arriba cuando n es grande.
- Las gráficas usan escala logarítmica en el eje Y; una barra el doble de alta no es el doble de tiempo.
