# Proyecto final: Sistema de gestión y análisis de rutas mediante grafos

Aplicación Java + JavaFX para construir, importar, guardar y analizar grafos de ubicaciones (vértices) y
conexiones con peso (aristas). Incluye BFS, DFS, Dijkstra, QuickSort, Shell Sort y un análisis empírico
de tiempos con tabla y gráfica.

## Cómo ejecutar

Requisitos: JDK 17 o superior (el `pom.xml` compila con `release 17`) y Maven.

```
mvn javafx:run
```

Desde IntelliJ: abrir el proyecto como Maven, recargar Maven y ejecutar la clase `Launcher`
(`com.schooltracker.proyectofinal.Launcher`).

## Qué hace cada parte de la pantalla

| Zona | Función |
|---|---|
| Barra superior: **Dirigido / No Dirigido** | Cambia el tipo de grafo |
| Barra superior: **combo de CSV** | Carga un CSV del proyecto: `ejemplo_universidad`, `grafo_peque` (20 vértices), `grafo_mediano` (100), `grafo_grande` (500) |
| Barra superior: **Abrir CSV...** | Carga cualquier CSV del disco (con validación y reporte de errores) |
| Barra superior: **Guardar CSV** | Guarda el grafo actual (creado a mano o modificado) en un CSV |
| Barra superior: **Grafo / Analisis** | Alterna entre el dibujo del grafo y las gráficas del análisis empírico |
| Panel lateral: **Vértices** | Agregar, modificar (renombrar) y eliminar vértices. Se escribe el id (número) o el nombre |
| Panel lateral: **Aristas** | Agregar, modificar el peso y eliminar conexiones (origen y destino por id o nombre) |
| Panel lateral: **Búsqueda** | BFS y DFS desde el vértice inicial elegido; muestra el orden de visita |
| Panel lateral: **Ruta Óptima** | Dijkstra: origen, destino, secuencia de vértices y costo total |
| Panel lateral: **Ordenamiento** | QuickSort o Shell Sort de las conexiones por peso o por nombre; la lista completa se abre en una ventana |

Notas de uso:
- Solo se **dibujan** grafos de hasta 50 vértices; con más, la pantalla lo avisa (los algoritmos siguen funcionando).
- Al guardar, los vértices sin conexiones no se escriben (el CSV solo guarda conexiones).
- El análisis empírico mide la primera vez que se entra a "Analisis" (unos 10 a 30 segundos); "Volver a medir" lo repite.

## Formato del CSV

```
origen,destino,peso
Biblioteca,Laboratorio,100
Biblioteca,Cafeteria,150
```

El lector valida: columnas requeridas (cabecera), registros incompletos, vértices vacíos, pesos numéricos no
negativos, conexiones de un vértice consigo mismo y conexiones duplicadas. Informa todos los errores con su
número de línea y, si no hay errores, el número de vértices y aristas importados.

## Organización del código

```
src/main/java/com/schooltracker/proyectofinal/
  Aplicacion, Launcher        arranque de JavaFX
  Controlador                 une la vista con el modelo y los algoritmos
  Model/                      Grafo (lista y matriz de adyacencia), Vertice, Arista, MainModel
    Archivos/                 Lector (importar y validar), Escritor (guardar), ResultadoImportacion
    AnalisisEmpirico          mide los tiempos de las operaciones (punto 6)
  Algoritmos/                 BFS, DFS, Dijkstra, QuickSort, ShellSort, CriteriosOrden, Resultado
  View/                       MainView, NavBar, SideBar, GrafoView, AnalisisView, Grafica, VentanaOrden
src/main/resources/CSV/       archivos de prueba (20, 100 y 500 vértices) y el ejemplo del enunciado
pruebas/Pruebas.java          pruebas automáticas de lector, escritor, BFS, DFS y Dijkstra
docs/analisis_teorico.md      complejidad de cada algoritmo, justificada con este código
```

## Pruebas

```
mvn compile
javac -cp target/classes -d target/pruebas pruebas/Pruebas.java
java -cp target/classes:target/pruebas Pruebas        (en Windows, usar ; en lugar de :)
```

Resultado esperado: `Correctas: 648  Fallas: 0`.
