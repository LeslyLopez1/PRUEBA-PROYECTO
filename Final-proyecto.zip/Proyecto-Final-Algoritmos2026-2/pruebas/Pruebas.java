import com.schooltracker.proyectofinal.Algoritmos.*;
import com.schooltracker.proyectofinal.Model.*;
import com.schooltracker.proyectofinal.Model.Archivos.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Pruebas {
    static int ok = 0, fallos = 0;
    static void check(boolean cond, String nombre) { if (cond) ok++; else { fallos++; System.out.println("FALLA: " + nombre); } }

    static ResultadoImportacion leer(String contenido, boolean dirigido) throws Exception {
        File f = File.createTempFile("prueba", ".csv"); f.deleteOnExit();
        Files.write(f.toPath(), contenido.getBytes("UTF-8"));
        return new Lector().importarDesdeArchivo(f, dirigido);
    }
    static boolean contiene(ResultadoImportacion r, String parte) {
        for (String e : r.getErrores()) if (e.contains(parte)) return true; return false;
    }

    public static void main(String[] args) throws Exception {
        // ---- Lector: caso válido
        ResultadoImportacion r = leer("origen,destino,peso\nA,B,10\nB,C,2.5\nA,C,7\n", true);
        check(!r.tieneErrores() && r.getVertices() == 3 && r.getAristas() == 3, "csv válido cuenta 3/3");
        r = leer("﻿origen,destino,peso\r\nA,B,10\r\n\r\nB,C,5\r\n", true);
        check(!r.tieneErrores() && r.getAristas() == 2, "BOM, CRLF y líneas vacías");
        r = leer("ORIGEN, Destino ,PESO\nA,B,1\n", true);
        check(!r.tieneErrores(), "cabecera sin importar mayúsculas/espacios");
        // ---- errores
        r = leer("a,b,c\nA,B,1\n", true);
        check(contiene(r, "columnas requeridas"), "cabecera incorrecta");
        r = leer("A,B,1\nB,C,2\n", true);
        check(contiene(r, "columnas requeridas"), "sin cabecera");
        r = leer("origen,destino\nA,B\n", true);
        check(contiene(r, "columnas requeridas"), "cabecera de 2 columnas");
        r = leer("", true);
        check(contiene(r, "vacío"), "archivo vacío");
        r = leer("origen,destino,peso\n", true);
        check(contiene(r, "ninguna conexión"), "solo cabecera");
        r = leer("origen,destino,peso\nA,B,abc\n", true);
        check(contiene(r, "no numérico") && r.getAristas() == 0, "peso no numérico");
        r = leer("origen,destino,peso\nA,B,-5\n", true);
        check(contiene(r, "no negativo"), "peso negativo");
        r = leer("origen,destino,peso\nA,B,NaN\n", true);
        check(contiene(r, "no negativo"), "peso NaN");
        r = leer("origen,destino,peso\n,B,5\n", true);
        check(contiene(r, "vértice vacío"), "origen vacío");
        r = leer("origen,destino,peso\nA,,5\n", true);
        check(contiene(r, "vértice vacío"), "destino vacío");
        r = leer("origen,destino,peso\nA,B\n", true);
        check(contiene(r, "incompleto"), "registro con 2 columnas");
        r = leer("origen,destino,peso\nA,B,\n", true);
        check(contiene(r, "falta el peso"), "peso vacío");
        r = leer("origen,destino,peso\nA,B,1,9\n", true);
        check(contiene(r, "incompleto"), "registro con 4 columnas");
        r = leer("origen,destino,peso\nA,A,5\n", true);
        check(contiene(r, "consigo mismo"), "bucle");
        r = leer("origen,destino,peso\nA,B,5\nA,B,9\n", true);
        check(contiene(r, "duplicada"), "duplicada dirigido");
        r = leer("origen,destino,peso\nA,B,5\nB,A,9\n", true);
        check(!r.tieneErrores() && r.getAristas() == 2, "A->B y B->A NO son duplicadas en dirigido");
        r = leer("origen,destino,peso\nA,B,5\nB,A,9\n", false);
        check(contiene(r, "duplicada"), "A-B y B-A SÍ son duplicadas en no dirigido");
        r = leer("origen,destino,peso\nA,B,x\nC,D,-1\nE,E,3\nF,G,\n", true);
        check(r.getErrores().size() == 4, "informa todos los errores (" + r.getErrores().size() + ")");
        check(r.getErrores().get(0).startsWith("Línea 2"), "número de línea correcto");
        // ---- estricto (lo usa el análisis)
        try { new Lector().leerDesdeRecurso("/CSV/noexiste.csv", true); check(false, "recurso inexistente"); }
        catch (IOException e) { check(true, ""); }
        // ---- CSV del proyecto
        String[] nombres = {"ejemplo_universidad", "grafo_peque", "grafo_mediano", "grafo_grande"};
        int[][] esperado = {{6, 8}, {-1, 30}, {-1, 1500}, {-1, 25000}};
        for (int i = 0; i < nombres.length; i++) {
            ResultadoImportacion x = new Lector().importarDesdeRecurso("/CSV/" + nombres[i] + ".csv", true);
            check(!x.tieneErrores(), nombres[i] + " sin errores: " + x.getErrores());
            check(x.getAristas() == esperado[i][1], nombres[i] + " aristas " + x.getAristas());
            System.out.println(nombres[i] + ": " + x.getVertices() + " vértices, " + x.getAristas() + " aristas");
        }
        // ---- Escritor: ida y vuelta (dirigido y no dirigido), con aislado omitido
        for (boolean dir : new boolean[]{true, false}) {
            Grafo g = new Lector().importarDesdeRecurso("/CSV/grafo_mediano.csv", dir).getGrafo();
            g.agregarVertice(new Vertice(9999, "Aislado"));
            File f = File.createTempFile("ida", ".csv"); f.deleteOnExit();
            int n = new Escritor().guardar(g, f);
            ResultadoImportacion vuelta = new Lector().importarDesdeArchivo(f, dir);
            check(!vuelta.tieneErrores(), "vuelta sin errores " + dir);
            check(n == vuelta.getAristas() && n == g.getTodasLasAristas().size(), "aristas ida y vuelta " + dir + " " + n);
            check(vuelta.getVertices() == g.getVertices().size() - 1, "aislado omitido " + dir);
            double suma1 = 0, suma2 = 0;
            for (Arista a : g.getTodasLasAristas()) suma1 += a.getPeso();
            for (Arista a : vuelta.getGrafo().getTodasLasAristas()) suma2 += a.getPeso();
            check(Math.abs(suma1 - suma2) < 1e-9, "pesos iguales " + dir);
        }
        Grafo gp = new Grafo(true); gp.agregarVertice(new Vertice(1, "A")); gp.agregarVertice(new Vertice(2, "B"));
        gp.agregarArista(1, 2, 2.5); gp.agregarArista(2, 1, 100);
        File fp = File.createTempFile("pesos", ".csv"); fp.deleteOnExit(); new Escritor().guardar(gp, fp);
        String txt = new String(Files.readAllBytes(fp.toPath()), "UTF-8").replace("\r", "");
        check(txt.equals("origen,destino,peso\nA,B,2.5\nB,A,100\n") || txt.equals("origen,destino,peso\nB,A,100\nA,B,2.5\n"), "formato de pesos: " + txt.replace("\n", "|"));
        Grafo gc = new Grafo(true); gc.agregarVertice(new Vertice(1, "A,x")); gc.agregarVertice(new Vertice(2, "B")); gc.agregarArista(1, 2, 1);
        try { new Escritor().guardar(gc, fp); check(false, "coma en nombre"); } catch (IllegalArgumentException e) { check(true, ""); }

        // ---- BFS / DFS en el ejemplo del PDF
        Grafo ej = new Lector().importarDesdeRecurso("/CSV/ejemplo_universidad.csv", true).getGrafo();
        check(nombres(BFS.recorrer(ej, 1)).equals("Biblioteca,Laboratorio,Cafeteria,Ingenieria,Rectoria,Gimnasio"), "BFS ejemplo " + nombres(BFS.recorrer(ej, 1)));
        check(nombres(DFS.recorrer(ej, 1)).equals("Biblioteca,Laboratorio,Ingenieria,Gimnasio,Cafeteria,Rectoria"), "DFS ejemplo " + nombres(DFS.recorrer(ej, 1)));
        check(nombres(BFS.recorrer(ej, 6)).equals("Gimnasio"), "BFS desde sumidero");
        try { BFS.recorrer(ej, 99); check(false, "BFS inicio inexistente"); } catch (IllegalArgumentException e) { check(true, ""); }
        try { DFS.recorrer(ej, 99); check(false, "DFS inicio inexistente"); } catch (IllegalArgumentException e) { check(true, ""); }

        // ---- BFS / DFS contra referencias en 300 grafos al azar
        Random rnd = new Random(7);
        for (int t = 0; t < 300; t++) {
            boolean dir = rnd.nextBoolean();
            Grafo g = new Grafo(dir);
            int n = 2 + rnd.nextInt(25);
            for (int i = 1; i <= n; i++) g.agregarVertice(i);
            int m = rnd.nextInt(n * 3);
            for (int i = 0; i < m; i++) g.agregarArista(1 + rnd.nextInt(n), 1 + rnd.nextInt(n), rnd.nextInt(50));
            int ini = 1 + rnd.nextInt(n);
            // DFS recursivo de referencia
            List<Integer> ref = new ArrayList<>(); dfsRef(g, ini, new HashSet<>(), ref);
            List<Integer> mio = ids(DFS.recorrer(g, ini));
            check(ref.equals(mio), "DFS == recursivo #" + t);
            // BFS de referencia por niveles
            Map<Integer, Integer> nivel = new HashMap<>(); Deque<Integer> q = new ArrayDeque<>(); nivel.put(ini, 0); q.add(ini);
            while (!q.isEmpty()) { int u = q.poll(); for (Arista a : g.getAdyacentes(u)) if (!nivel.containsKey(a.getDestino().getId())) { nivel.put(a.getDestino().getId(), nivel.get(u) + 1); q.add(a.getDestino().getId()); } }
            List<Integer> b = ids(BFS.recorrer(g, ini));
            boolean niveles = true; for (int i = 1; i < b.size(); i++) if (nivel.get(b.get(i)) < nivel.get(b.get(i - 1))) niveles = false;
            check(new HashSet<>(b).equals(nivel.keySet()) && b.size() == nivel.size() && niveles && b.get(0) == ini, "BFS niveles #" + t);
        }
        // ---- grafo grande: DFS no se desborda (camino de 20000 vértices)
        Grafo cadena = new Grafo(true); int N = 20000;
        // (agregarVertice es O(V) por la matriz; se usa una cadena de tamaño moderado)
        N = 3000; for (int i = 1; i <= N; i++) cadena.agregarVertice(i); for (int i = 1; i < N; i++) cadena.agregarArista(i, i + 1, 1);
        check(DFS.recorrer(cadena, 1).size() == N && BFS.recorrer(cadena, 1).size() == N, "cadena larga sin desbordar");
        // ---- Dijkstra sobre el ejemplo
        Resultado res = Dijkstra.calcular(ej, 1, 6);
        check(res.isEncontrada() && res.getCosto() == 310.0, "Dijkstra 310");

        System.out.println("Correctas: " + ok + "  Fallas: " + fallos);
    }
    static void dfsRef(Grafo g, int u, Set<Integer> vis, List<Integer> out) {
        vis.add(u); out.add(u);
        for (Arista a : g.getAdyacentes(u)) if (!vis.contains(a.getDestino().getId())) dfsRef(g, a.getDestino().getId(), vis, out);
    }
    static List<Integer> ids(List<Vertice> l) { List<Integer> r = new ArrayList<>(); for (Vertice v : l) r.add(v.getId()); return r; }
    static String nombres(List<Vertice> l) { StringBuilder s = new StringBuilder(); for (Vertice v : l) { if (s.length() > 0) s.append(","); s.append(v.getEtiqueta()); } return s.toString(); }
}
